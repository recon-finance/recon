// Inserts demo content so the UI can be viewed without live feeds or an API key.
//  - RPT 1 is a DEMO REPORT hand-compiled from live sources on 1 Nov 2026 (real figures, real links). It shows the target long-form format.
//  - RPT 2-5 are short SAMPLE stories with placeholder text.
require('dotenv').config();
const db = require('./lib/db');
db.prepare(`DELETE FROM stories WHERE cluster_key LIKE 'demo-%'`).run();
db.prepare('DELETE FROM calls').run();
const cols = 'cluster_key,kind,topic,headline,summary,key_points,why_it_matters,disagreements,confidence,sources,source_count,assessment,analysis,read_mins';
const ins = db.prepare(`INSERT INTO stories (${cols}) VALUES (${cols.split(',').map(() => '?').join(',')})`);
const wc = a => [...a.situation, ...a.background, ...a.market_reaction, ...a.compare, ...a.watch.map(w => w.what), ...a.numbers.map(n => `${n.label} ${n.value} ${n.context}`)].join(' ').split(/\s+/).filter(Boolean).length;

// ---------- RPT 1: flagship demo ----------
const src1 = [
 { name: 'Bank of England', url: 'https://www.bankofengland.co.uk/monetary-policy/the-interest-rate-bank-rate', title: 'Interest rates and Bank Rate: our latest decision' },
 { name: 'Mortgage One', url: 'https://www.mortgageonefinance.co.uk/news/next-bank-of-england-meeting', title: 'Next Bank of England Meeting' },
 { name: 'Cambridge Currencies', url: 'https://cambridgecurrencies.com/next-bank-of-england-interest-rate-decision/', title: 'Next Bank of England Interest Rate Decision' },
 { name: 'RateProbability', url: 'https://rateprobability.com/boe', title: 'BoE Rate Odds: MPC Meeting Probabilities' },
 { name: 'Finance Calendar', url: 'https://www.financecalendar.com/bank-of-england-mpc-meetings/', title: 'Bank of England MPC Rate Decision: Next Release' },
 { name: 'Advisor Perspectives', url: 'https://www.advisorperspectives.com/dshort/updates/2026/10/28/feds-interest-rate-decision-october-28-2026', title: "Fed's Interest Rate Decision: October 28, 2026" },
 { name: 'EBC', url: 'https://www.ebc.com/forex/ecb-interest-rate-decision-october-2026', title: 'ECB Holds Rates at 2.50% as Lagarde Announces Departure' },
];
const A1 = {
 meta: { kind: 'DEMO', note: 'Hand-compiled on 1 Nov 2026 from the linked live sources to show the target format. In production this is generated and number-verified automatically.' },
 situation: [
  'Bank Rate stands at 3.75%, and the next Monetary Policy Committee decision is due on 5 November at 12:00 UK time, published alongside a new Monetary Policy Report [1][3]. Markets enter the meeting heavily positioned for a rise: overnight index swap pricing as of 1 November implies a 94% chance of a 25bp increase to 4.00% [4].',
  'The committee has moved towards tightening all year. In February four of nine members voted to cut Bank Rate to 3.5%. By the 30 July meeting three were voting to raise it to 4%, and on 17 September the same three, Megan Greene, Catherine Mann and Huw Pill, did so again as the MPC held for a sixth time in 2026 by 6-3 [2]. Bank Rate has not changed since the cut on 18 December 2025 [3].',
  'The Bank’s own messaging has hardened around energy. It says conflict in the Middle East has disrupted energy transport and supply, pushing up household fuel and utility costs, and that so far the effect on UK price and wage setting has been limited [1]. The warning is conditional: the longer the volatility lasts, the bigger the inflation impact and the more likely a Bank Rate rise becomes [1]. The same text puts inflation at 3.1% and expects it to rise further [1].',
  'Sell-side forecasters have followed the committee. Capital Economics, Oxford Economics, Bank of America and Fidelity International all expect rises in November and February, taking Bank Rate to 4.25%, while Barclays says the next increase will probably come as soon as November [2].',
 ],
 numbers: [
  { label: 'Bank Rate', value: '3.75%', source: 1, context: 'Current; next decision 5 Nov' },
  { label: 'Unchanged since', value: '18 Dec 2025', source: 3, context: 'Date of the last cut' },
  { label: 'Sept MPC vote', value: '6-3', source: 2, context: 'Hold; sixth hold of 2026' },
  { label: 'Votes for 4%', value: '3', source: 2, context: 'Greene, Mann, Pill' },
  { label: 'Hike probability, 5 Nov', value: '94%', source: 4, context: 'OIS-implied, as of 1 Nov' },
  { label: 'Implied post-meeting rate', value: '3.99%', source: 4, context: 'Market-implied' },
  { label: 'Hikes priced, 12 months', value: '4.22', source: 4, context: 'At a 25bp step' },
  { label: 'UK inflation (BoE text)', value: '3.1%', source: 1, context: 'Bank expects it to rise' },
  { label: 'Fed funds target', value: '3.75-4.00%', source: 6, context: 'Held 28 Oct, 10-2' },
  { label: 'ECB deposit rate', value: '2.50%', source: 7, context: 'Held 29 Oct' },
 ],
 background: [
  'The pattern of the vote is the thing to track. The committee moved one vote further towards a rise at every meeting from March to July, then held that shape in September [2]. A 6-3 hold with the same three dissenters points to a hawkish bloc rather than a drift.',
  'The Bank is not moving in isolation. The Federal Reserve held at 3.75%-4.00% on 28 October by 10-2, with two members preferring a hike, after raising in September for the first time since 2023 [6]. The ECB held its deposit rate at 2.50% on 29 October after raising it in September, with euro-area inflation at 3.8% [7].',
 ],
 market_reaction: [
  'Beyond November, the curve prices a net 105.5bp of rises over twelve months, equivalent to 4.22 hikes at a 25bp step [4]. Futures pricing on 29 October gave roughly an 82% chance of a 25bp ECB hike to 2.75% in December [7].',
 ],
 compare: [
  'Sources agree on the level (3.75%) [1][2][3] and on the 6-3 September split [2][3]. They differ in tone: the Bank’s own text stresses uncertainty and conditionality [1], while broker and adviser commentary treats a November rise as the base case [2][4].',
  'One data point needs care: the Bank’s page shows a 3.5% headline inflation figure while its decision text cites 3.1%. The headline figure is likely the newer reading, so check the latest ONS release before quoting either [1].',
 ],
 watch: [
  { when: '5 Nov', what: 'MPC decision and Monetary Policy Report: the vote split and the inflation projections [3].' },
  { when: '8-9 Dec', what: 'Federal Reserve meeting, decision on the second day [3].' },
  { when: '16-17 Dec', what: 'ECB meeting; the Bank of England also decides on 17 December [3][5].' },
 ],
};
A1.words = wc(A1);
const AN1 = {
 thesis: 'A hike on 5 November is the consensus. The vote split and the new inflation forecasts are the real news.',
 body: [
  'With swap pricing at 94% for a 25bp rise, the decision itself carries little surprise. What can move sterling and gilts is the signal around it: whether the three-member bloc that voted for 4% in September grows, and how the committee describes the risk that energy-driven inflation spreads into pay and pricing.',
  'The wider backdrop reinforces the hawkish read. The Fed and the ECB both held in the last week of October, yet markets still price further hikes at both: another 25bp at the Fed and roughly an 82% chance of one at the ECB in December. The Bank is not tightening alone, which lowers the odds of a sterling-specific shock but raises the risk of a synchronised repricing at the long end if three central banks keep leaning towards hikes.',
  'The next real test is 17 December, when the Bank and the ECB decide on the same day. If November delivers a hike with guidance towards a pause, that day shows whether the November move was a one-off.',
 ],
 call: { bank: 'BOE', event: 'boe-2026-11-05', expect: 'HIKE' },
 links: [{ type: 'event', ref: 'boe-2026-11-05' }, { type: 'event', ref: 'fed-2026-12-09' }, { type: 'event', ref: 'ecb-2026-12-17' }, { type: 'event', ref: 'boe-2026-12-17' }],
 counter: 'If Middle East energy prices ease before the meeting, the committee could prefer to wait for the new forecasts, and a hold would be a large surprise to a market priced at 94%.',
 conviction: 'MEDIUM',
};
ins.run('demo-0', 'REPORT', 'RATES & BOE', 'DEMO REPORT: BoE decision 5 Nov, a 94% priced rise as the MPC hawks hold their bloc',
 'Markets price a 94% chance the Bank of England raises Bank Rate by 25bp on 5 November. Three MPC members already voted for 4% in September. The Bank cites energy-driven inflation risk. The Fed and ECB both held last week.',
 JSON.stringify(['94% priced for +25bp to 4.00% on 5 Nov', 'September vote 6-3 hold; three voted for 4%', 'Energy-driven inflation is the Bank’s stated trigger', 'Fed (3.75-4.00%) and ECB (2.50%) both held']),
 'Gilt yields, sterling and fixed-rate mortgage pricing move on the rate path the MPC signals, not only on the headline decision.',
 JSON.stringify([]), 'HIGH',
 JSON.stringify(src1), src1.length, JSON.stringify(A1), JSON.stringify(AN1), Math.max(1, Math.round(A1.words / 200)));

// the flagship's logged call (pending until the 5 Nov decision is resolved from the rate data)
db.prepare(`INSERT INTO calls (story_id,bank,event_id,event_at,expect,conviction,baseline_rate,mkt_expect,mkt_pct) VALUES ((SELECT id FROM stories WHERE cluster_key='demo-0'),'BOE','boe-2026-11-05','2026-11-05T12:00:00Z','HIKE','MEDIUM',3.75,'HIKE',94)`).run();

// ---------- RPT 2-5: short samples ----------
const S = (n) => n.map(x => ({ name: x, url: '#', title: 'Sample source' }));
const samples = [
 ['UK ECONOMY','SAMPLE: Services inflation stays sticky as pay growth cools slowly','Sample story. Outlets agree underlying price pressure is easing only gradually, but differ on how much wages are to blame.',['Headline rate eased on energy','Services prices remain elevated','Pay growth slowing but still firm'],'Sticky services inflation tends to delay rate cuts and keep gilt yields high.',['Outlets differ on whether wages or energy are the bigger driver'],'MEDIUM',['BBC News','The Telegraph','The Independent','The Economist']],
 ['BANKING','SAMPLE: Lenders flag margin pressure as mortgage competition heats up','Sample story. Banking coverage points to tighter margins as lenders reprice fixed deals ahead of a possible rate move.',['Fixed deals repriced within days','Competition squeezing net interest margins','Savings rates broadly stable'],'Margin pressure feeds into UK bank earnings and share prices.',[],'HIGH',['City AM','The Telegraph','This is Money','Financial Times']],
 ['MARKETS','SAMPLE: FTSE 100 slips as gilt yields climb','Sample story. UK shares fell while gilt yields rose, with rate-sensitive and housebuilder stocks hit hardest.',['Gilt yields at multi-week highs','Housebuilders and property lag','Energy and mining hold up'],'Higher gilt yields raise borrowing costs for the government and for UK homeowners.',[],'HIGH',['Sky News','City AM','CNBC','The Independent']],
 ['PROPERTY','SAMPLE: Mortgage approvals soften as buyers wait for rate clarity','Sample story. Housing coverage suggests buyers are pausing, with outlets split on how deep the slowdown will be.',['Approvals lower month on month','Lenders pulling and repricing deals','Agents report slower viewings'],'Weaker housing activity feeds into consumer spending and bank lending.',['Disagreement on whether this is a pause or a longer downturn'],'LOW',['BBC News','The Guardian','This is Money']],
];
samples.forEach((r, i) => {
 const A = { meta: { kind: 'SAMPLE', note: 'Sample story with placeholder text. Live reports carry a full 3-5 minute assessment, a numbers table and a RECON Analysis.' }, situation: [r[2].replace('Sample story. ', '')], numbers: [], background: [], market_reaction: [], compare: [], watch: [], words: 0 };
 ins.run('demo-' + (i + 1), 'REPORT', r[0], r[1], r[2], JSON.stringify(r[3]), r[4], JSON.stringify(r[5]), r[6], JSON.stringify(S(r[7])), r[7].length, JSON.stringify(A), null, null);
});
// ---------- two SAMPLE official releases (placeholder text) ----------
[['ONS','UK ECONOMY','SAMPLE OFFICIAL RELEASE: ONS publishes its latest labour market bulletin','Sample release. ONS publishes the latest labour market statistics; live items summarise the headline figures and what changed.',['Headline figures appear here','Changes versus the previous release','Link to the full ONS bulletin'],'Labour market data feeds into the Bank of England\u2019s view of domestic price pressure.'],
 ['OBR','FISCAL','SAMPLE OFFICIAL RELEASE: OBR publishes supplementary fiscal data','Sample release. The OBR publishes supplementary fiscal tables; live items summarise the forecasts and what moved.',['Forecast changes appear here','Fiscal headroom commentary','Link to the OBR publication'],'Fiscal forecasts shape gilt supply and the Chancellor\u2019s room for manoeuvre.']].forEach((r, i) => {
 const A = { meta: { kind: 'SAMPLE', note: 'Placeholder for an official release. Live releases are written from the full text of the publication, with every number checked against it.' }, situation: [r[3].replace('Sample release. ', '')], numbers: [], background: [], market_reaction: [], compare: [], watch: [], words: 0 };
 ins.run('demo-rel-' + i, 'RELEASE', r[1], r[2], r[3], JSON.stringify(r[4]), r[5], JSON.stringify([]), 'PRIMARY', JSON.stringify([{ name: r[0], url: '#', title: 'Sample official release' }]), 1, JSON.stringify(A), null, null);
});
console.log('seeded', 1 + samples.length + 2, '| flagship words:', A1.words);
