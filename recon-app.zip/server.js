require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const path = require('path');
const cron = require('node-cron');
const db = require('./lib/db');
const pipeline = require('./lib/pipeline');
const { sendConfirmation, sendDaily } = require('./lib/newsletter');
const { TOPICS } = require('./lib/sources');
const trackrecord = require('./lib/trackrecord');
const rateprob = require('./lib/rateprobability');
const fs = require('fs');
const RATES = require('./lib/paths').RATES;

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);   // behind the host's proxy: real client IP for rate limiting
app.get('/healthz', (_q, res) => { try { db.prepare('SELECT 1').get(); res.send('ok'); } catch { res.sendStatus(500); } });
app.use(express.json({ limit: '10kb' }));
app.use((req, res, next) => { res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY' }); next(); });
app.use(express.static(path.join(__dirname, 'public'), { setHeaders: (res, f) => { if (f.endsWith('sw.js')) res.set('Cache-Control', 'no-cache'); } }));

app.get('/api/stories', (req, res) => res.json(require('./lib/api').storiesPayload(req.query.topic)));

app.get('/api/rates', (_q, res) => {
  try { res.set('Cache-Control', 'public, max-age=300').json(JSON.parse(fs.readFileSync(RATES, 'utf8'))); }
  catch { res.status(500).json({ error: 'rates unavailable' }); }
});

app.get('/api/trackrecord', (_q, res) => res.json(trackrecord.stats()));

// naive per-IP rate limit for signup
const hits = new Map();
const limited = ip => { const now = Date.now(); const a = (hits.get(ip) || []).filter(t => now - t < 3600e3); a.push(now); hits.set(ip, a); return a.length > 8; };

app.post('/api/subscribe', async (req, res) => {
  if (limited(req.ip)) return res.status(429).json({ error: 'Too many attempts. Try later.' });
  const email = String(req.body.email || '').trim().toLowerCase();
  if (!/^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(email) || email.length > 254) return res.status(400).json({ error: 'Invalid email address.' });
  const topics = (Array.isArray(req.body.topics) ? req.body.topics : []).filter(t => TOPICS.includes(t));
  let sub = db.prepare(`SELECT * FROM subscribers WHERE email=?`).get(email);
  if (!sub) {
    const token = crypto.randomBytes(24).toString('hex');
    db.prepare(`INSERT INTO subscribers (email,token,topics) VALUES (?,?,?)`).run(email, token, JSON.stringify(topics));
    sub = db.prepare(`SELECT * FROM subscribers WHERE email=?`).get(email);
  } else if (sub.confirmed) {
    db.prepare(`UPDATE subscribers SET topics=? WHERE id=?`).run(JSON.stringify(topics), sub.id); // preference update; no email so addresses can't be probed
    return res.json({ ok: true });
  }
  try { await sendConfirmation(sub); } catch (e) { console.log('confirm mail failed', e.message); }
  res.json({ ok: true }); // same response either way
});

const page = (title, msg) => `<!DOCTYPE html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>${title}</title><body style="background:#000;color:#b3b3b3;font-family:Helvetica,Arial,sans-serif;display:grid;place-items:center;height:100vh;margin:0"><div style="border:1px solid #242424;padding:32px;max-width:420px"><div style="color:#fff;letter-spacing:.2em;font-size:12px;font-weight:700">RECON · ${title}</div><p>${msg}</p><a href="/" style="color:#fff">Return to feed</a></div>`;
app.get('/confirm', (req, res) => {
  const r = db.prepare(`UPDATE subscribers SET confirmed=1, confirmed_at=datetime('now') WHERE token=?`).run(String(req.query.token || ''));
  res.send(r.changes ? page('CONFIRMED', 'Subscription active. The first briefing arrives at 07:00 UK time.') : page('INVALID LINK', 'This link is not valid.'));
});
app.get('/unsubscribe', (req, res) => {
  db.prepare(`DELETE FROM subscribers WHERE token=?`).run(String(req.query.token || ''));
  res.send(page('UNSUBSCRIBED', 'Your email has been removed.'));
});
app.post('/unsubscribe', (req, res) => { // one-click (RFC 8058)
  db.prepare(`DELETE FROM subscribers WHERE token=?`).run(String(req.query.token || '')); res.sendStatus(200);
});

// admin triggers (set ADMIN_TOKEN)
const admin = (req, res, next) => (process.env.ADMIN_TOKEN && req.get('x-admin-token') === process.env.ADMIN_TOKEN) ? next() : res.sendStatus(403);
const { sendTo } = require('./lib/newsletter');
app.get('/api/admin/stats', admin, (_q, res) => res.json({
  subscribers: db.prepare('SELECT COUNT(*) c FROM subscribers WHERE confirmed=1').get().c, pending: db.prepare('SELECT COUNT(*) c FROM subscribers WHERE confirmed=0').get().c,
  reports24h: db.prepare("SELECT COUNT(*) c FROM stories WHERE kind!='RELEASE' AND updated_at >= datetime('now','-24 hours')").get().c,
  releases24h: db.prepare("SELECT COUNT(*) c FROM stories WHERE kind='RELEASE' AND updated_at >= datetime('now','-24 hours')").get().c,
  articles24h: db.prepare("SELECT COUNT(*) c FROM articles WHERE fetched_at >= datetime('now','-24 hours')").get().c,
  resend: !!process.env.RESEND_API_KEY, smtp: !!process.env.SMTP_HOST, ai: require('./lib/llm').configured(), aiCap: +(process.env.MAX_LLM_CALLS_PER_DAY || 150) }));
app.post('/api/admin/test-email', admin, async (req, res) => { const e = String(req.body?.email || '').trim(); if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) return res.status(400).json({ error: 'bad email' }); try { res.json(await sendTo(e)); } catch (err) { res.status(500).json({ error: err.message }); } });
app.get('/api/usage', admin, (_q, res) => res.json(db.prepare('SELECT * FROM llm_usage ORDER BY day DESC LIMIT 31').all()));
app.get('/api/admin/backup', admin, async (_q, res) => {   // consistent copy of the database (subscribers, reports, track record)
  const f = require('path').join(require('os').tmpdir(), `recon-backup-${Date.now()}.db`);
  try { await db.backup(f); res.download(f, 'recon-backup.db', () => require('fs').unlink(f, () => {})); } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/health', admin, (_q, res) => res.json(db.prepare(`SELECT name,url,tier,required,last_ok,last_error,items,note,checked_at FROM source_health ORDER BY required DESC, tier, name`).all()));
app.post('/api/admin/rates', admin, (req, res) => {
  const b = req.body; // full replacement of config/rates.json
  if (!b || !Array.isArray(b.banks) || !b.banks.every(x => x.id && x.name && x.rate && x.next)) return res.status(400).json({ error: 'bad shape' });
  fs.writeFileSync(RATES, JSON.stringify(b, null, 2)); res.json({ ok: true });
});
app.post('/api/admin/rates/refresh', admin, async (_q, res) => { const r = await rateprob.refresh(); trackrecord.resolve(); res.json(r); });
app.post('/api/admin/resolve', admin, (req, res) => { const { bank, event, finalRate } = req.body || {}; res.json({ resolved: trackrecord.manualResolve(String(bank), String(event), +finalRate) }); });
app.post('/api/admin/refresh', admin, async (_q, res) => res.json({ stories: await pipeline() }));
app.post('/api/admin/send', admin, async (_q, res) => res.json({ sent: await sendDaily() }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`RECON online :${PORT}${process.env.DEMO === '1' ? ' [DEMO]' : ''}`));

if (process.env.DEMO !== '1') {
  cron.schedule('*/30 * * * *', () => pipeline().catch(e => console.log(e.message)));
  // market pricing from rateprobability.com twice a day (before the 07:00 email, and mid-afternoon); then resolve any due calls
  cron.schedule(process.env.RATES_CRON || '30 6,16 * * *', () => rateprob.refresh().then(() => trackrecord.resolve()).catch(e => console.log(e.message)), { timezone: 'Europe/London' });
  cron.schedule('15 * * * *', () => { try { trackrecord.resolve(); } catch (e) { console.log(e.message); } });
  cron.schedule('0 7 * * *', () => sendDaily().catch(e => console.log(e.message)), { timezone: 'Europe/London' });
  pipeline().catch(e => console.log(e.message));
}
