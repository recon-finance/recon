# £0 launch: GitHub + Buttondown

Free: hosting (GitHub Actions + Pages, public repository), the newsletter list (Buttondown, first 100 subscribers), the web address (`you.github.io/recon`), no domain needed.
Not free: the AI. Lean mode (`LEAN=1`, the workflow default) is roughly £7-£15/month at ~13 items a day (an estimate; the run summary shows real usage).

## Set-up (about 30 minutes)
1. Accounts: GitHub, Buttondown (buttondown.com), Anthropic Console (prepay a small amount, set a monthly limit).
2. GitHub: new **public** repository `recon`. Upload everything from the unzipped folder EXCEPT the hidden `.github` folder. Then **Add file > Create new file**, name it `.github/workflows/recon.yml`, paste the contents of that file from the zip.
3. Repo **Settings > Pages > Source: GitHub Actions**.
4. Buttondown: create the newsletter; copy your API key (Settings > API) and the sign-up form address (the `action="..."` URL on the Embed page).
5. Repo **Settings > Secrets and variables > Actions**: secrets `ANTHROPIC_API_KEY`, `BUTTONDOWN_API_KEY`; variable `SUBSCRIBE_FORM_ACTION`. Optional: `BUTTONDOWN_AUTOSEND=1`, `MAX_LLM_CALLS_PER_DAY`.
6. **Actions > RECON > Run workflow**; read the run summary.
7. Each morning from 07:00 UK a **draft** email appears in Buttondown: read it, press Send. When you trust it, set `BUTTONDOWN_AUTOSEND=1`. (If Buttondown refuses API email creation on the free plan, the run log says so: keep using drafts or use their paid plan.)

## Moving to Resend later (e.g. when you pass ~100 readers)
1. Buy a domain, verify it in Resend, create a list and an API key.
2. Export your subscribers from Buttondown (CSV) and import them into the Resend list (they have already given double opt-in consent; keep the same sender name and purpose).
3. Deploy the sign-up Worker (`cloudflare/signup-worker.mjs`, see the Resend guide).
4. In GitHub set variables `NEWSLETTER_PROVIDER=resend`, `SUBSCRIBE_MODE=worker`, `SUBSCRIBE_FORM_ACTION=<worker address>/subscribe`, `MAIL_FROM`, `RESEND_SEGMENT_ID` (or `RESEND_AUDIENCE_ID`), and secret `RESEND_API_KEY`. Nothing else changes.

## Limits
- Buttondown free = 100 subscribers.
- The repository is public, and so is the saved `data` branch (news and reports only; subscribers live in Buttondown).
- GitHub disables scheduled workflows in a public repo after 60 days of no repo activity (RECON saves data every run, which should count). If it stops, press "Enable workflow".
- Scheduled runs can start a few minutes late. No control panel and no per-subscriber sector choice in this version.
