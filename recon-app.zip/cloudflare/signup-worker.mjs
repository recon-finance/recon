// RECON sign-up endpoint for Cloudflare Workers (free tier). Stateless double opt-in: nothing is stored here.
//   POST /subscribe  {email}  -> emails a signed confirmation link (valid 7 days)
//   GET  /confirm?t=...       -> verifies the link, adds the contact to your Resend list, redirects to the site
// Settings (Worker > Settings > Variables and secrets):
//   RESEND_API_KEY (secret) · SIGNING_SECRET (secret: any long random text) · MAIL_FROM · SITE_URL
//   RESEND_AUDIENCE_ID or RESEND_SEGMENT_ID (whichever your Resend dashboard shows for your list)
const enc = new TextEncoder();
const b64u = buf => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = s => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
const key = secret => crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/;
const DAY = 864e5;

async function makeToken(email, secret, now = Date.now()) {
  const payload = enc.encode(`${email}|${now + 7 * DAY}`);
  const sig = await crypto.subtle.sign('HMAC', await key(secret), payload);
  return `${b64u(payload)}.${b64u(sig)}`;
}
async function readToken(t, secret, now = Date.now()) {
  try {
    const [p, s] = String(t).split('.');
    if (!p || !s || !(await crypto.subtle.verify('HMAC', await key(secret), unb64u(s), unb64u(p)))) return null;
    const [email, exp] = new TextDecoder().decode(unb64u(p)).split('|');
    return +exp > now && EMAIL.test(email) ? email : null;
  } catch { return null; }
}

const resend = (env, path, body) => fetch('https://api.resend.com' + path, { method: 'POST', headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

// Resend's contacts API has been reorganised (audiences -> segments). Try the documented shapes in turn.
async function addContact(env, email) {
  const tries = [];
  if (env.RESEND_AUDIENCE_ID) tries.push(() => resend(env, `/audiences/${env.RESEND_AUDIENCE_ID}/contacts`, { email, unsubscribed: false }));
  tries.push(() => resend(env, '/contacts', { email, unsubscribed: false, ...(env.RESEND_SEGMENT_ID ? { segments: [{ id: env.RESEND_SEGMENT_ID }] } : {}) }));
  let last = 'no attempt';
  for (const t of tries) { const r = await t(); if (r.ok) return true; last = `${r.status} ${(await r.text()).slice(0, 160)}`; if (r.status === 409) return true; }   // 409 = already there
  throw new Error('Resend contact create failed: ' + last);
}

const json = (o, status, cors) => new Response(JSON.stringify(o), { status, headers: { 'Content-Type': 'application/json', ...cors } });

export default {
  async fetch(req, env) {
    const url = new URL(req.url), site = (env.SITE_URL || '').replace(/\/$/, '');
    let origin = ''; try { origin = new URL(site).origin; } catch {}
    const cors = { 'Access-Control-Allow-Origin': origin || '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Vary': 'Origin' };
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

    if (url.pathname === '/subscribe' && req.method === 'POST') {
      let email = ''; try { email = String((await req.json()).email || '').trim().toLowerCase(); } catch {}
      if (!EMAIL.test(email) || email.length > 254) return json({ error: 'Please enter a valid email address.' }, 400, cors);
      const link = `${url.origin}/confirm?t=${await makeToken(email, env.SIGNING_SECRET)}`;
      const r = await resend(env, '/emails', { from: env.MAIL_FROM, to: [email], subject: 'Confirm your RECON subscription',
        text: `Confirm your subscription to the RECON UK morning brief:\n${link}\n\nIf you didn't ask for this, ignore this email and you won't be added.`,
        html: `<div style="background:#000;padding:24px;font-family:Helvetica,Arial,sans-serif;color:#b3b3b3"><div style="max-width:560px;margin:auto;border:1px solid #242424;padding:28px"><div style="color:#fff;letter-spacing:.3em;font-size:13px;font-weight:700">RECON</div><p style="margin:18px 0">Confirm your subscription to the UK morning brief.</p><p><a href="${link}" style="background:#fff;color:#000;padding:12px 18px;text-decoration:none;font-weight:700;letter-spacing:.12em;font-size:12px">CONFIRM SUBSCRIPTION</a></p><p style="color:#777;font-size:12px;margin-top:22px">If you didn't ask for this, ignore this email and you won't be added.</p></div></div>` });
      if (!r.ok) return json({ error: 'Could not send the confirmation email. Please try again later.' }, 502, cors);
      return json({ ok: true }, 200, cors);   // same answer whether or not the address is already subscribed
    }

    if (url.pathname === '/confirm') {
      const email = await readToken(url.searchParams.get('t') || '', env.SIGNING_SECRET);
      if (!email) return new Response('This confirmation link is invalid or has expired. Please subscribe again on the site.', { status: 400 });
      try { await addContact(env, email); } catch { return new Response('Something went wrong confirming your subscription. Please try again.', { status: 502 }); }
      return Response.redirect(`${site || 'https://example.com'}/#subscribed`, 302);
    }
    return new Response('RECON sign-up service', { status: 200 });
  },
};
export { makeToken, readToken, addContact };
