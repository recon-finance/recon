// Static export for £0 hosting (GitHub Pages / Cloudflare Pages / Netlify): dist/ = index.html + data/*.json (+ service worker).
// Sign-ups post straight to the newsletter provider's form endpoint (SUBSCRIBE_FORM_ACTION), so no server is needed.
const fs = require('fs');
const path = require('path');

function build(out = process.env.OUT_DIR || 'dist') {
  const { storiesPayload, ratesPayload } = require('../lib/api');
  const trackrecord = require('../lib/trackrecord');
  const pub = path.join(__dirname, '..', 'public');
  fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(path.join(out, 'data'), { recursive: true });
  const w = (f, o) => fs.writeFileSync(path.join(out, 'data', f), JSON.stringify(o));
  w('stories.json', storiesPayload()); w('rates.json', ratesPayload()); w('trackrecord.json', trackrecord.stats());

  let h = fs.readFileSync(path.join(pub, 'index.html'), 'utf8');
  const sub = (a, b) => { if (!(a.test ? a.test(h) : h.includes(a))) throw new Error('static build: pattern not found: ' + String(a).slice(0, 60)); h = h.replace(a, b); };
  sub(/fetch\('\/api\/stories'\)/, "fetch('data/stories.json',{cache:'no-cache'})");
  sub(/fetch\('\/api\/rates'\)/, "fetch('data/rates.json',{cache:'no-cache'})");
  sub(/fetch\('\/api\/trackrecord'\)/, "fetch('data/trackrecord.json',{cache:'no-cache'})");
  sub("register('/sw.js')", "register('./sw.js')");
  sub('Double opt-in. Unsubscribe in one click. Your selected area of operations sets your sectors.', 'Double opt-in. Unsubscribe in one click.');
  const action = process.env.SUBSCRIBE_FORM_ACTION || '';
  const mode = process.env.SUBSCRIBE_MODE || 'form';   // form = a provider's sign-up form, e.g. Buttondown (no-cors POST); worker = our Cloudflare sign-up endpoint for Resend (JSON)
  const post = action && mode === 'worker'
    ? `const em=$('#em').value;if(!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(em))throw new Error('Invalid email address.');const r=await fetch(${JSON.stringify(action)},{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:em})});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||'Could not subscribe. Please try again later.');`
    : action
    ? `const em=$('#em').value;if(!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(em))throw new Error('Invalid email address.');await fetch(${JSON.stringify(action)},{method:'POST',mode:'no-cors',body:new URLSearchParams({email:em,embed:'1'})});`
    : `throw new Error('Sign-ups open soon.');`;
  sub(/const r=await fetch\('\/api\/subscribe'[^\n]*\n\s*const j=await r.json\(\);if\(!r.ok\)throw new Error\(j.error\|\|'Failed'\);/, post);
  sub("m.textContent='Check your inbox to confirm.'", "m.textContent='Check your inbox to confirm (and your spam folder).'");
  if (!action) console.log('[site] WARNING: SUBSCRIBE_FORM_ACTION not set: the sign-up box will say "Sign-ups open soon".');
  fs.writeFileSync(path.join(out, 'index.html'), h);
  fs.copyFileSync(path.join(pub, 'sw.js'), path.join(out, 'sw.js'));
  fs.writeFileSync(path.join(out, '.nojekyll'), '');
  fs.writeFileSync(path.join(out, 'robots.txt'), 'User-agent: *\nAllow: /\n');
  console.log(`[site] built ${out}/ (${storiesPayload().stories.length} stories)`);
}
module.exports = { build };
if (require.main === module) { require('dotenv').config(); build(); }
