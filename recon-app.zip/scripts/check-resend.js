// Run once on your own machine: `RESEND_API_KEY=... RESEND_SEGMENT_ID=... MAIL_FROM="RECON <brief@yourdomain>" TEST_EMAIL=you@x.com npm run check:resend`
// Verifies your domain, that a contact can be added, and that a DRAFT broadcast can be created (nothing is sent to anyone).
require('dotenv').config();
const K = process.env.RESEND_API_KEY;
const api = async (m, p, b) => { const r = await fetch('https://api.resend.com' + p, { method: m, headers: { Authorization: `Bearer ${K}`, 'Content-Type': 'application/json' }, body: b ? JSON.stringify(b) : undefined }); const t = await r.text(); let j = {}; try { j = JSON.parse(t); } catch {} return { ok: r.ok, status: r.status, j, t }; };
(async () => {
  if (!K) { console.log('Set RESEND_API_KEY first.'); process.exit(1); }
  let bad = 0; const say = (ok, msg) => { console.log((ok ? 'OK    ' : 'FAIL  ') + msg); if (!ok) bad++; };
  const d = await api('GET', '/domains');
  const doms = d.j.data || [];
  say(d.ok, d.ok ? `domains: ${doms.map(x => `${x.name} (${x.status})`).join(', ') || 'none added yet'}` : `domains lookup ${d.status}: ${d.t.slice(0, 120)}`);
  const from = (process.env.MAIL_FROM || '').match(/@([^>\s]+)/);
  if (from) say(doms.some(x => x.name === from[1] && x.status === 'verified'), `MAIL_FROM domain "${from[1]}" is verified in Resend`);
  const email = process.env.TEST_EMAIL;
  if (email) {
    let ok = false, last = '';
    if (process.env.RESEND_AUDIENCE_ID) { const r = await api('POST', `/audiences/${process.env.RESEND_AUDIENCE_ID}/contacts`, { email, unsubscribed: false }); ok = r.ok; last = `audiences route ${r.status} ${r.t.slice(0, 100)}`; }
    if (!ok) { const r = await api('POST', '/contacts', { email, unsubscribed: false, ...(process.env.RESEND_SEGMENT_ID ? { segments: [{ id: process.env.RESEND_SEGMENT_ID }] } : {}) }); ok = r.ok || r.status === 409; last = `contacts route ${r.status} ${r.t.slice(0, 100)}`; }
    say(ok, 'add contact ' + (ok ? 'works' : '-> ' + last));
  } else console.log('SKIP  contact test (set TEST_EMAIL)');
  const list = process.env.RESEND_SEGMENT_ID ? { segment_id: process.env.RESEND_SEGMENT_ID } : process.env.RESEND_AUDIENCE_ID ? { audience_id: process.env.RESEND_AUDIENCE_ID } : null;
  if (!list) { say(false, 'set RESEND_SEGMENT_ID or RESEND_AUDIENCE_ID'); }
  else {
    const b = await api('POST', '/broadcasts', { ...list, from: process.env.MAIL_FROM, subject: 'RECON check (draft, not sent)', html: '<p>Check. {{{RESEND_UNSUBSCRIBE_URL}}}</p>', name: 'RECON check' });
    say(b.ok, b.ok ? 'draft broadcast created (delete it in the Resend dashboard if you like)' : `create broadcast ${b.status}: ${b.t.slice(0, 160)}`);
  }
  console.log(bad ? '\nFix the FAIL lines above (see Resend dashboard / docs) before launch.' : '\nResend set-up looks good.');
  process.exit(bad ? 1 : 0);
})();
