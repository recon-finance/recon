// One full RECON cycle, for scheduled runners (GitHub Actions): news -> reports -> releases -> analysis -> rates -> resolve calls
// -> daily brief (once per London day, from 07:00) -> static site export. State lives in DATA_DIR (the workflow saves it between runs).
require('dotenv').config();
const db = require('../lib/db');
const pipeline = require('../lib/pipeline');
const rateprob = require('../lib/rateprobability');
const trackrecord = require('../lib/trackrecord');
const nl = require('../lib/newsletter');
const bd = require('../lib/buttondown');
const rsd = require('../lib/resend');
const { ratesPayload } = require('../lib/api');

const meta = k => (db.prepare('SELECT value FROM meta WHERE key=?').get(k) || {}).value;
const setMeta = (k, v) => db.prepare('INSERT OR REPLACE INTO meta (key,value) VALUES (?,?)').run(k, String(v));

(async () => {
  // market pricing about twice a day (not every run)
  if (process.env.SKIP_RATES !== '1' && (!meta('last_rates_at') || Date.now() - +meta('last_rates_at') > 10 * 3600e3)) {
    await rateprob.refresh().catch(e => console.log('[rates] failed:', e.message)); setMeta('last_rates_at', Date.now());
  }
  await pipeline().catch(e => console.log('[pipeline] failed:', e.message));
  trackrecord.resolve();

  if (['buttondown', 'resend'].includes(process.env.NEWSLETTER_PROVIDER) && bd.briefDue()) {
    const sel = nl.storiesFor([]);
    if (sel.all.length) {
      try {
        const rates = ratesPayload().banks.map(b => `${b.code} ${b.rate}${b.unit || '%'}`).join(' · ');
        const info = await (process.env.NEWSLETTER_PROVIDER === 'resend' ? rsd : bd).publish(sel, { mins: nl.readMins(sel.all), rates, date: new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Europe/London' }) });
        bd.markSent(); console.log(`[brief] ${info.mode}: ${info.subject}`);
      } catch (e) { console.log('[brief] FAILED:', e.message); }   // not marked as sent: the next run retries
    } else console.log('[brief] nothing to send yet');
  }
  require('./build-site').build();
  if (process.env.GITHUB_STEP_SUMMARY) {   // human-readable report on the Actions run page
    const rows = db.prepare('SELECT name,tier,required,last_ok,items,last_error FROM source_health ORDER BY required DESC, (last_ok IS NULL) DESC, name').all();
    const use = db.prepare('SELECT * FROM llm_usage ORDER BY day DESC LIMIT 3').all();
    const c = q => db.prepare(q).get().c;
    const md = [`## RECON run summary`, `Reports (24h): **${c("SELECT COUNT(*) c FROM stories WHERE kind!='RELEASE' AND updated_at >= datetime('now','-24 hours')")}** · Official releases (24h): **${c("SELECT COUNT(*) c FROM stories WHERE kind='RELEASE' AND updated_at >= datetime('now','-24 hours')")}** · Articles fetched (24h): **${c("SELECT COUNT(*) c FROM articles WHERE fetched_at >= datetime('now','-24 hours')")}**`,
      `\n### AI usage\n| Day | Calls | Tokens in | Tokens out |\n|---|---|---|---|`, ...use.map(u => `| ${u.day} | ${u.calls} | ${u.input_tokens} | ${u.output_tokens} |`),
      `\n### Sources (required first; problems at the top)\n| Source | Tier | Last OK | Items | Problem |\n|---|---|---|---|---|`,
      ...rows.map(r => `| ${r.name}${r.required ? ' *' : ''} | ${r.tier} | ${r.last_ok ? r.last_ok.slice(0, 16) : '**never**'} | ${r.items} | ${(r.last_error || '').replace(/\|/g, '/').slice(0, 80)} |`)].join('\n');
    require('fs').appendFileSync(process.env.GITHUB_STEP_SUMMARY, md + '\n');
  }
  db.pragma('wal_checkpoint(TRUNCATE)');   // flush the database into a single file before it is saved
  process.exit(0);
})();
