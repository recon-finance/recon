// Run on your own machine/server: `npm run check:feeds`. Tests every ENABLED feed and prints status, item count, newest item.
// Exits non-zero if any REQUIRED source fails, so you can run it in CI or before deploying.
require('dotenv').config();
const Parser = require('rss-parser');
const SOURCES = require('../lib/sources');
const parser = new Parser({ timeout: 15000, headers: { 'User-Agent': 'ReconBot/1.0 (+news aggregation; links back to sources)' } });
(async () => {
  let badRequired = 0;
  for (const s of SOURCES.filter(x => x.enabled !== false)) {
    try {
      const f = await parser.parseURL(s.url);
      const items = f.items || [], newest = items.map(i => new Date(i.isoDate || i.pubDate || 0)).sort((a, b) => b - a)[0];
      const age = newest ? Math.round((Date.now() - newest) / 36e5) + 'h old' : 'no dates';
      console.log(`OK    [${s.tier}] ${s.name.padEnd(16)} ${String(items.length).padStart(3)} items, newest ${age}  ${s.url}`);
    } catch (e) {
      if (s.required) badRequired++;
      console.log(`FAIL  [${s.tier}] ${s.name.padEnd(16)} ${e.message.slice(0, 70)}  ${s.url}${s.required ? '   <-- REQUIRED' : ''}${s.site ? `\n        try autodiscovery from ${s.site}` : ''}`);
    }
  }
  console.log(badRequired ? `\n${badRequired} required source(s) failing: fix the URL in config/publishers.json (or let ingest autodiscover).` : '\nAll required sources OK.');
  process.exit(badRequired ? 1 : 0);
})();
