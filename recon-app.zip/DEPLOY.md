# Putting RECON online (about 30 minutes, mostly clicking)

**Railway** rents you a small always-on computer on the internet. You give it the code, it runs 24/7 and gives you a web address.
(Fly.io is similar but needs a command line. Railway is point-and-click, so that is what this is set up for.)

## Monthly cost (checked 1 Nov 2026; prices change)
- Railway Hobby: $5/month, includes $5 of usage, card required, 5 GB storage volume.
- Resend (email): free = 3,000 emails/month and 100/day (about 100 subscribers). Pro = $20/month for 50,000.
- A domain name (needed to send email from your own address): typically £10-15/year from any registrar.
- Anthropic API: pay per use. Set a monthly spend limit in the console. The app also stops after `MAX_LLM_CALLS_PER_DAY` AI calls (default 150).

## Steps
1. **Accounts**: GitHub, Railway (sign in with GitHub), Resend, Anthropic Console (console.anthropic.com).
2. **Code to GitHub**: unzip recon-app.zip. GitHub > New repository > name `recon`, Private > "uploading an existing file" > drag in everything from *inside* the unzipped folder > Commit.
3. **Railway**: New Project > Deploy from GitHub repo > pick `recon`.
4. **Storage**: add a Volume to the service with mount path `/data` (keeps subscribers and data across updates).
5. **Variables**: paste the contents of `.env.production.example` (fill every `<...>`). Make `ADMIN_TOKEN` a long random password.
6. **Web address**: service Settings > Networking > Generate Domain. Copy it into `BASE_URL`. Railway redeploys.
7. **Email**: Resend > Domains > add your domain > add the DNS records at your registrar > wait for "verified" > create an API key > set `RESEND_API_KEY` and `MAIL_FROM`. (Railway's cheap plan blocks normal SMTP email, which is why RECON sends through Resend's web API.) Until the domain is verified, Resend only delivers to the address you signed up with.
8. **Checks**: `https://YOUR-ADDRESS/healthz` shows `ok`. `https://YOUR-ADDRESS/admin.html` is the control panel (enter ADMIN_TOKEN): look at the Sources table, press "Refresh news now", then "Send me a test".
9. **After a day**: read the reports. Any source marked "never" or with a problem needs its URL fixed in `config/publishers.json` (or tell me which and I will).

## Weekly
Control panel > Download backup (contains subscribers, reports and the track record).

## Before inviting anyone
Add a privacy policy page (you collect emails: UK GDPR/PECR). Sign-up already uses double opt-in and every email has a one-click unsubscribe.
