# RECON: UK economics, banking & markets brief

Pipeline: RSS from reputable UK outlets (plus international outlets, kept only when UK-relevant) -> cluster same-event articles -> publish only if >= 3 distinct outlets
-> Claude writes one condensed story (facts only from the articles, conflicts flagged, sources linked)
-> UK-relevance gate (AI scores each story; <3 is dropped) -> web feed + double opt-in daily email at 07:00 Europe/London.

Commute features: reading-time estimate ("Tube read"), a rates strip in the email, and offline reading (service worker keeps the latest brief for tunnels).

## Run
    npm install
    cp .env.example .env      # add ANTHROPIC_API_KEY, BASE_URL, SMTP_*
    npm start                 # ingests every 30 min, emails daily at 07:00 UK
    npm run seed              # optional: sample stories to preview the UI (DEMO=1 npm start to skip live jobs)

Admin: POST /api/admin/refresh and /api/admin/send with header `x-admin-token`.

## Before launch
- Run `node lib/ingest.js` and check which feeds fail; fix URLs in lib/sources.js. Reuters/Bloomberg have no public RSS: license their APIs.
- Feeds give headlines + short snippets, so summaries are only as deep as that. Fetching full text needs publisher licences.
- Check each outlet's terms for AI summarisation/commercial use. Keep source links prominent.
- Email: set SPF/DKIM on your sending domain. Signup is double opt-in with one-click unsubscribe (UK PECR/GDPR). Add a privacy policy page.
- Host on anything that runs Node with a persistent disk (Railway, Fly, Render, a VPS). SQLite file lives in data/.
- Footer states "not financial advice"; keep it. Consider human review of HIGH-impact stories.

## Policy-rate KPIs
`config/rates.json` feeds the BoE / ECB / Fed panel (rate, last decision, countdown to next, market pricing, source link).
It is maintained by hand: update it after each decision, or `POST /api/admin/rates` (header `x-admin-token`) with the full JSON.
Market-pricing lines are indicative and should be refreshed with the rate. Automating this means wiring official/market-data APIs
(ECB Data Portal, BoE IADB, FRED, plus a futures/OIS provider for pricing).

## Sound
All effects are synthesised in the browser with WebAudio (no audio files). They only start after the first click/keypress
(browser rule), can be switched off with the AUDIO button (remembered per browser), and never autoplay.

## Long-form assessments, number checking and RECON Analysis
- `lib/fulltext.js` fetches full article text (Readability) so the AI has real detail, not RSS snippets. Paywalled outlets (FT, WSJ, Economist, Times, Telegraph, Bloomberg) are skipped and fall back to snippets, so reports built mostly on them will be thin. **Check each publisher's terms/licensing before enabling this commercially.** `FULLTEXT=0` disables it.
- `lib/synthesise.js` asks for a 600-900 word assessment (situation, numbers table, background, market reaction, source comparison, what to watch) with inline [n] source markers. It never pads: thin sources give short reports (a read time is computed from the real word count).
- `lib/verify.js` is the guardrail: every number in the assessment must appear in the source text. Sentences or table rows with unverifiable figures are removed, and a BLUF with unverifiable figures blocks publication. Logged as "verification removed...".
- `lib/analyse.js` writes the **RECON Analysis** in a second pass: thesis, reasoning, counter-case, conviction, linked to other recent reports (last 72h) and `config/calendar.json` events. Numbers are checked against the supplied context, and links to non-existent reports/events are discarded. Labelled as AI opinion, not advice.
- Keep `config/calendar.json` current (add ONS release dates, Budget, results days). Only verified dates.
- `ANALYSIS_MODEL` lets you use a different (e.g. stronger) model for the analysis step.
- Reports deep-link as `/#rpt-<id>`; the email links to them.

## Source policy (OSINT, no per-publisher deals)
`config/publishers.json` is the single source of truth, enforced in code:
- **tier `full`** (9 sources): public-sector / primary sources we may read in full and rewrite: gov.uk (HM Treasury, HMRC, CMA, OBR, ONS) under the Open Government Licence v3.0 (**verified**), plus Bank of England, FCA, Federal Reserve, ECB (**assumed**: standard public-body reuse; read each `termsUrl` once and set `status` to `verified`).
- **tier `snippet`**: news outlets (BBC, Guardian, Sky, Telegraph, Independent, City AM, This is Money, FT, Economist, CNBC, MarketWatch, WSJ). Only the feed's own headline + a short description (max 400 chars) is stored. Never fetched in full, never rewritten at length. They provide corroboration (the 3+ source rule) and the links readers click.
- Reports with at least `minFullSources` (default 1) full-tier source in the cluster get the long assessment; otherwise they are published as a **BRIEF** (BLUF, key points, UK angle, analysis) with no assessment. Fully automatic.
- Adding a source = adding an entry. Unlisted sources are never ingested.
- Not legal advice. Snippet reuse and paraphrase still rest on each outlet's feed terms; if a publisher objects, delete its entry.

## Policy rates (rateprobability.com) and track record
- `lib/rateprobability.js` runs at 06:30 and 16:30 UK (`RATES_CRON` to change), parses rate, next meeting and market pricing, merges into `config/rates.json`, stores snapshots, and **fails safe** (keeps last data, shows STALE). It honours robots.txt and identifies itself.
- The parser was written from page text seen in search results (the site blocks automated fetchers from my environment, so I could not test against the live page). **Run `npm run probe:rates` first.** If it is blocked or the layout differs, set `RATES_BROWSER=1` (needs `npm i playwright`) or adjust `parsePage`. Check the site's terms / ask for an API before depending on it.
- `/fed` and `/ecb` page paths are assumed; only `/boe` is confirmed.
- Track record: `lib/trackrecord.js`. The analysis may attach `call:{bank,event,expect}` for a rate decision. Logged before the event (past-dated events rejected), immutable, resolved from the first snapshot taken 1h+ after the decision (VOID if none within 72h; `POST /api/admin/resolve {bank,event,finalRate}` as a manual fallback). Each call is compared with the market favourite at the time.

## Sources in use (updated)
**Primary (full text, rewritten; `required`)**: HM Treasury, HMRC, CMA, OBR, ONS, Bank of England (news + publications), FCA, Federal Reserve, ECB.
**News (snippet-only: headline + short description, linked; never full text)**: Financial Times (UK, global economy, markets, companies), Bloomberg (markets, economics, politics), Reuters, BBC News, The Guardian (business + economics), City AM, IFS.
Also enabled (snippet-only): Sky News, The Telegraph, The Independent, This is Money, The Economist, CNBC, MarketWatch, WSJ. Any source can be switched off with `enabled:false` in `config/publishers.json`.

Notes
- **Reuters** has had no public RSS since June 2020. RECON uses Google News RSS (`site:reuters.com`) for headline-only discovery. This is the least clear route legally; set `enabled:false` to drop it, or license the Reuters API.
- **Bloomberg** public RSS carries headlines + a short blurb only. **FT** RSS likewise.
- **IFS** owns the copyright in all material and asks external users to email outputs@ifs.org.uk: RECON uses headline + link only. Emailing them for permission to summarise is worth doing.
- Feed URLs could not be tested from the build environment. Run **`npm run check:feeds`** first. Failing feeds with a `site` set are autodiscovered at ingest; the log tells you the new URL to save. `GET /api/health` (admin token) shows per-source status; ingest logs `!! REQUIRED source silent` for any primary source with nothing kept in 48h/7 days.
- Scheduled items (e.g. ONS release calendar) are ignored until their publication time. ONS calendar pages are followed through to the bulletin for the real content.

## Official releases stream
`lib/releases.js`: publications from primary sources become reports **without** needing 3-source corroboration (`kind=RELEASE`, labelled OFFICIAL, "PRIMARY DOCUMENT"). Max 3 per source per run (`RELEASES_PER_SOURCE`) and 10 per run (`MAX_RELEASES`) so ONS/OBR are not drowned out; ordered ONS, OBR, BoE, Treasury, FCA, HMRC, CMA, Fed, ECB. The AI skips non-economic items (`skip`), every number is checked against the document, and each processed URL is remembered (`release_seen`). They get a RECON Analysis like any report, have their own filter in the sector rail, and a block at the top of the daily email.
